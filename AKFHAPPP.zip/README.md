# AK FASHION HUB - Production Deployment Guide

## 📋 Overview

A complete, production-ready ERP + POS + Inventory Management system for garment retail stores.

**Tech Stack:**
- Frontend: Vanilla JavaScript (no frameworks required)
- Backend: Google Apps Script
- Database: Google Sheets
- Hosting: Any static hosting (Vercel, Netlify, Firebase, etc.)
- Offline: PWA with Service Worker

**No Monthly Costs:**
- Google Sheets: Free tier (millions of rows)
- Google Apps Script: Free tier (up to 20,000 executions/day)
- Hosting: Free tier available on Vercel/Netlify

---

## 🚀 Quick Start (5 minutes)

### Step 1: Set Up Google Sheet & Backend

1. **Create a new Google Sheet:**
   - Go to [sheets.google.com](https://sheets.google.com)
   - Click "Create new spreadsheet"
   - Name it: "AK Fashion Hub - Store Data"

2. **Add Google Apps Script:**
   - Click `Extensions` → `Apps Script`
   - Delete default code
   - Copy all code from `GoogleAppsScript.gs` file
   - Paste it into the editor

3. **Initialize Database:**
   - In the Apps Script editor, click the dropdown next to the play button
   - Select function `setup` and click ▶ Run
   - Grant permissions when prompted
   - Wait for completion message
   - Check your Google Sheet - all tabs should now be created with demo data

4. **Deploy as Web App:**
   - Click `Deploy` → `New deployment`
   - Select type: `Web app`
   - Execute as: Your email
   - Who has access: `Anyone`
   - Click Deploy
   - Click `Authorize` and approve permissions
   - **Copy the "Web App URL"** (looks like `https://script.google.com/macros/s/AKfycb...xxxxx.../exec`)

### Step 2: Configure Frontend

1. Open `index.html` in a text editor
2. Find line that says: `API_URL: ''`
3. Paste your Web App URL between the quotes:
   ```javascript
   API_URL: 'https://script.google.com/macros/s/AKfycbXXXXXXXXXXXXXXXXXXXXXXXXX/exec'
   ```
4. Save the file

### Step 3: Test Locally

1. Open `index.html` in a web browser
2. Try demo login:
   - Mobile: `9999900001`
   - Password: `admin@123`
   - PIN: `1234`

3. If it works ✓, go to Step 4. If not, double-check your API_URL and that the setup() function ran successfully.

### Step 4: Deploy to the Web

**Option A: Vercel (Recommended - 2 clicks)**
1. Push your files to GitHub (or create a new repo with just these 4 files)
2. Go to [vercel.com](https://vercel.com)
3. Connect your GitHub repo
4. Click Deploy
5. Your app is live instantly

**Option B: Netlify**
1. Drag and drop your 4 files onto [netlify.com](https://netlify.com)
2. Your app is live in seconds

**Option C: Firebase Hosting**
```bash
npm install -g firebase-tools
firebase login
firebase init hosting
# Select your project
# Choose current directory: .
# Deploy:
firebase deploy
```

**Option D: Your Own Server**
- Copy all 4 files to your web server
- Ensure HTTPS is enabled
- Access via your domain

---

## 📁 File Structure

```
AK-FASHION-HUB-PRD/
├── index.html                    # Main application (frontend)
├── manifest.json                 # PWA configuration
├── sw.js                         # Service worker (offline support)
├── GoogleAppsScript.gs           # Backend (paste into Apps Script)
└── README.md                     # This file
```

---

## 🔐 Default Login Credentials

### Admin Account
- **Mobile:** 9999900001
- **Password:** admin@123
- **PIN:** 1234
- **Permissions:** All

### Staff Account
- **Mobile:** 9999900002
- **Password:** staff@123
- **PIN:** 1234
- **Permissions:** Billing, Stock Check, Returns, Exchanges (limited)

**⚠️ Change these immediately after first login:**
1. Go to Settings → Staff Management
2. Edit each staff account
3. Change passwords and PINs

---

## 📱 Features Complete

### ✅ Dashboard
- Today's sales & profit
- Inventory count & low stock alerts
- Recent bills preview

### ✅ POS / Billing
- Barcode scan-based cart
- Product variants (color + size)
- Discount support (% or fixed)
- Multiple payment modes (Cash, UPI, Card)
- Customer management (optional)
- Auto-calculate totals

### ✅ Product Management
- Add/Edit/Delete products
- Multiple variants per product
- Images & descriptions
- Brand & Fabric Type tracking
- Status (Active/Inactive/Discontinued)
- Auto-generated UID & Barcode
- QR Code generation (client-side)

### ✅ Inventory Management
- Real-time stock tracking
- Color-wise stock
- Size-wise stock
- Location tracking (Floor/Rack/Shelf)
- Low stock alerts
- Stock adjustment with audit trail

### ✅ Customer Management
- Customer database
- Mobile-based lookup
- Purchase history
- Loyalty points tracking
- Due balance tracking
- Birthday reminders (future feature)

### ✅ Supplier Management
- Supplier database
- Purchase order tracking
- Auto stock increase on purchase
- GSTIN & Bank details storage

### ✅ Reports & Analytics
- Daily/Monthly sales
- Top selling products
- Inventory value
- Staff performance
- Expense tracking
- Revenue by payment mode

### ✅ Staff Management
- Role-based access control
- Activity logging
- Login history
- Session timeout
- Failed login lockout (5 attempts = 15 min lock)
- Password reset via OTP (placeholder)

### ✅ Offline & PWA
- Install as mobile app (iOS/Android)
- Desktop app (Windows/Mac)
- Works offline (reads cached data)
- Service Worker auto-sync

---

## 🔧 Google Sheets Database Structure

### Products Sheet
- UID (auto-generated)
- Barcode (same as UID)
- QR Code (generated)
- Product Name
- Gender (Men/Women/Kids)
- Brand
- Fabric Type (Cotton/Denim/etc.)
- Status (Active/Inactive/Discontinued)
- Cost Price, Sale Price, MRP
- Batch Number
- Location (Floor/Rack/Shelf)
- Tags (New Arrival, Best Seller, etc.)
- Images URL

### Variants Sheet
- One row per color+size combination
- Product reference
- Stock count
- Location details

### Customers Sheet
- Name, Mobile, Email
- Total Spend, Loyalty Points
- Due Balance
- Birthday

### Bills Sheet
- Bill Number (auto)
- Customer details
- Staff who created it
- Total with discount
- Payment mode
- Timestamp

### Staff Sheet
- Name, Mobile, Email
- Password Hash (SHA-256)
- PIN Hash
- Role (SuperAdmin/Admin/Staff)
- Permissions (JSON)
- Failed login attempts
- Account lock timestamp

### Other Sheets
- Activity Log (all actions)
- Login History (auth attempts)
- Suppliers
- Purchases
- Expenses

---

## 🔒 Security Features

✅ **Password Security:**
- SHA-256 hashing on backend
- Never stored plaintext
- Passwords not sent to frontend

✅ **PIN Verification:**
- 4-digit PIN stored as hash
- Verified server-side
- PIN gate on sensitive actions

✅ **Login Security:**
- Failed attempt counter
- Auto-lock after 5 failures for 15 minutes
- Admin unlock option
- Login history tracking

✅ **Session Management:**
- 20-minute auto-logout
- Stored in localStorage only
- Cleared on logout

✅ **Role-Based Access:**
- SuperAdmin: All features
- Admin: Most features, no staff management
- Staff: Limited to billing, stock check, returns

✅ **Audit Trail:**
- Every action logged with timestamp
- Staff name & ID recorded
- Admin can review logs

✅ **Data Privacy:**
- Passwords/PINs never logged
- Customer data isolated by transaction
- No sensitive data in URL

---

## 🐛 Troubleshooting

### "API_URL not configured" Error
- Make sure you pasted the Web App URL in index.html
- Check it starts with `https://script.google.com/macros/s/`

### Login fails
- Verify demo credentials are correct
- Check Google Sheet has staff data (run setup() if not)
- Open browser console (F12) for error details

### Stock doesn't update
- Make sure billing form is filled with customer details
- Pin verification might have failed - try PIN again

### App won't install (PWA)
- Make sure you're on HTTPS
- Give it a few seconds after first load
- Try "Add to Home Screen" (iOS) or "Install" (Android)

### Service Worker not updating
- Clear browser cache and do hard refresh (Ctrl+Shift+R)
- Check browser DevTools → Application → Service Workers

---

## 📊 Advanced Setup

### Multi-Store Support (Future Ready)
Current system supports single store. To add multi-store:
1. Add `StoreID` column to all data sheets
2. In backend: filter by store before returning data
3. In frontend: add store selector in login screen
4. Create one Apps Script per store, or share data with store IDs

### SMS Integration (OTP)
To enable SMS-based password reset:
1. Sign up for SMS gateway (Twilio, MSG91, Fast2SMS)
2. In `GoogleAppsScript.gs`, find `requestPasswordReset()` function
3. Uncomment and fill in the UrlFetchApp.fetch() call with your SMS provider's API
4. Test with a real mobile number

### Custom Branding
Edit CSS variables in index.html `<style>` block:
```css
--primary: #8B1538;          /* Main color */
--accent: #D4AF37;           /* Accent color */
--neutral-900: #111827;      /* Text color */
```

### Whatsapp Bill Integration
Already implemented! After creating a bill:
1. Click "Print Bill" or "Send WhatsApp"
2. Opens WhatsApp with pre-filled message
3. Customer receives bill via text

### Analytics Integration
To add Google Analytics:
1. Get your GA tracking ID from analytics.google.com
2. Add this to index.html `<head>`:
   ```html
   <script async src="https://www.googletagmanager.com/gtag/js?id=GA_ID"></script>
   <script>
     window.dataLayer = window.dataLayer || [];
     function gtag(){dataLayer.push(arguments);}
     gtag('js', new Date());
     gtag('config', 'GA_ID');
   </script>
   ```

---

## 🚦 Scaling Checklist

| Metric | Current Limit | When to Upgrade |
|--------|---------------|-----------------|
| Products | 100,000+ | Rarely needed |
| Daily Bills | 1000+ | Can go higher |
| Concurrent Users | 1 (via login) | Add Supabase for multi-user |
| API Calls/Day | 20,000 | Rarely hit |
| Data Size | 10GB | Years away |

When you outgrow free tier:
1. Migrate to Supabase (PostgreSQL)
2. Keep same UI, swap backend
3. Budget: $25-50/month

---

## 📞 Support & Next Steps

### Getting Help
1. Check browser console (F12 → Console) for errors
2. Check Google Sheet for data (is data saving?)
3. Check Apps Script logs (Executions tab)
4. Verify API URL is correct and Web App is deployed

### Feature Requests
- Add to Issues tab in repository
- Label as "enhancement"

### Common Customizations
- **Change colors:** Edit CSS variables
- **Add fields:** Add columns to Google Sheet, update frontend form
- **New report:** Add formula in Google Sheets, display in Reports tab
- **Custom printing:** Edit the print HTML in the code

---

## 📈 Usage Tips

### Backup Regularly
1. Go to Settings → Download Backup
2. Save the JSON file in Dropbox/Drive
3. Do this weekly

### Staff Onboarding
1. Create staff account in Staff Management
2. Share login credentials securely
3. Test login before handing over
4. Set appropriate permissions

### Inventory Best Practices
1. Scan barcodes consistently
2. Do weekly stock verification
3. Mark damaged/lost items immediately
4. Update locations when moving stock

### Daily Checklist
- [ ] Check low stock alerts
- [ ] Review daily sales
- [ ] Backup data (weekly)
- [ ] Review activity log (monthly)

---

## 🔄 Regular Maintenance

**Weekly:**
- Download backup
- Review sales reports
- Check low stock items

**Monthly:**
- Review staff performance
- Audit activity logs
- Update supplier info if needed

**Quarterly:**
- Full inventory count
- Deep database cleanup
- Customer loyalty rewards

---

## 📄 License & Terms

This system is provided as-is for use by AK Fashion Hub store.

**What's Free:**
- Code usage
- Google Sheets (free tier)
- Google Apps Script (free tier)
- Hosting options (Vercel, Netlify free tiers)

**What You Pay For (Optional):**
- Premium hosting
- SMS gateway (if enabling OTP)
- Custom domain
- Supabase (when scaling)

---

## 🎉 You're Ready!

Your AK Fashion Hub ERP system is now live!

**Next Steps:**
1. ✅ Access at your deployed URL
2. ✅ Change default passwords
3. ✅ Import your existing inventory (or start fresh)
4. ✅ Train staff on using the system
5. ✅ Set up daily backups
6. ✅ Enjoy streamlined operations!

**Questions?** Check the troubleshooting section or review the code comments.

---

**Version:** 1.0.0  
**Last Updated:** 2024  
**Status:** Production Ready ✅
