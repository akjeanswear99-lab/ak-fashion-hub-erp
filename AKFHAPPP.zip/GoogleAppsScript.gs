/**
 * ============================================================================
 * AK FASHION HUB - GOOGLE APPS SCRIPT BACKEND
 * Production-Grade Backend for ERP + POS + Inventory System
 * ============================================================================
 * DEPLOYMENT:
 * 1. Create new Google Sheet
 * 2. Extensions > Apps Script
 * 3. Replace all code with this file
 * 4. Click Deploy > New Deployment > Web app
 * 5. Copy the Web App URL and paste in frontend CONFIG
 * ============================================================================
 */

const SHEET_TABS = {
  PRODUCTS: 'Products',
  VARIANTS: 'Variants',
  CUSTOMERS: 'Customers',
  BILLS: 'Bills',
  BILL_ITEMS: 'BillItems',
  SUPPLIERS: 'Suppliers',
  PURCHASES: 'Purchases',
  STAFF: 'Staff',
  ACTIVITY_LOG: 'ActivityLog',
  LOGIN_HISTORY: 'LoginHistory',
  EXPENSES: 'Expenses',
};

const DB_SCHEMA = {
  Products: [
    'ProductID', 'UID', 'Barcode', 'QRCode', 'Name', 'Gender', 'Description',
    'Brand', 'FabricType', 'Status', 'CostPrice', 'SalePrice', 'MRP',
    'BatchNumber', 'Tags', 'SeasonTags', 'ImageURL', 'SizeChartURL',
    'SupplierID', 'TotalStock', 'CreatedDate', 'UpdatedDate'
  ],
  Variants: [
    'VariantID', 'ProductID', 'UID', 'Color', 'Size', 'Stock',
    'Floor', 'Rack', 'Shelf', 'CreatedDate'
  ],
  Customers: [
    'CustomerID', 'Name', 'Mobile', 'Email', 'Birthday', 'Address',
    'TotalSpend', 'LoyaltyPoints', 'DueBalance', 'CreatedDate'
  ],
  Bills: [
    'BillID', 'BillNumber', 'CustomerID', 'CustomerName', 'CustomerMobile',
    'StaffID', 'StaffName', 'Subtotal', 'DiscountPercent', 'DiscountAmount',
    'TaxAmount', 'TotalAmount', 'PaymentMode', 'Status', 'CreatedDate'
  ],
  BillItems: [
    'BillID', 'VariantID', 'ProductID', 'UID', 'Color', 'Size',
    'Quantity', 'SalePrice', 'LineTotal'
  ],
  Suppliers: [
    'SupplierID', 'Name', 'Mobile', 'Email', 'Address', 'City',
    'GSTIN', 'BankAccount', 'CreatedDate'
  ],
  Purchases: [
    'PurchaseID', 'SupplierID', 'SupplierName', 'VariantID', 'ProductID',
    'UID', 'Color', 'Size', 'Quantity', 'CostPrice', 'TotalAmount',
    'InvoiceNumber', 'CreatedDate'
  ],
  Staff: [
    'StaffID', 'Name', 'Mobile', 'Email', 'PasswordHash', 'PINHash',
    'Role', 'Permissions', 'Status', 'FailedLoginAttempts', 'LockedUntil',
    'LastLogin', 'CreatedDate'
  ],
  ActivityLog: [
    'LogID', 'Timestamp', 'StaffID', 'StaffName', 'Action', 'Details'
  ],
  LoginHistory: [
    'LogID', 'Timestamp', 'Mobile', 'StaffName', 'Role', 'Status', 'Reason'
  ],
  Expenses: [
    'ExpenseID', 'Date', 'Category', 'Description', 'Amount', 'StaffName', 'Notes', 'CreatedDate'
  ],
};

// ============================================================================
// SETUP - Initialize all sheets (run once)
// ============================================================================
function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  
  // Delete and recreate all sheets
  Object.values(SHEET_TABS).forEach(tabName => {
    const sheet = ss.getSheetByName(tabName);
    if (sheet) ss.deleteSheet(sheet);
  });

  // Create sheets with headers
  Object.entries(DB_SCHEMA).forEach(([tabName, headers]) => {
    const sheet = ss.insertSheet(tabName);
    sheet.appendRow(headers);
    sheet.setFrozenRows(1);
    sheet.autoResizeColumns(1, headers.length);
  });

  // Seed demo staff (hashed passwords)
  const staffSheet = ss.getSheetByName(SHEET_TABS.STAFF);
  const adminPwHash = simpleHash('admin@123');
  const staffPwHash = simpleHash('staff@123');
  const pinHash = simpleHash('1234');

  staffSheet.appendRow([
    'admin001', 'Anita Kapoor', '9999900001', 'admin@fashionhub.com',
    adminPwHash, pinHash, 'SuperAdmin',
    JSON.stringify({
      billing: true, stockEdit: true, productDelete: true, reports: true,
      staffManagement: true, expenseManagement: true
    }),
    'Active', 0, '', new Date().toISOString(), new Date().toISOString()
  ]);

  staffSheet.appendRow([
    'staff001', 'Ravi Sharma', '9999900002', 'ravi@fashionhub.com',
    staffPwHash, pinHash, 'Staff',
    JSON.stringify({
      billing: true, stockCheck: true, stockEdit: false, productDelete: false,
      returns: true, exchanges: true
    }),
    'Active', 0, '', new Date().toISOString(), new Date().toISOString()
  ]);

  // Seed demo supplier
  const supplierSheet = ss.getSheetByName(SHEET_TABS.SUPPLIERS);
  supplierSheet.appendRow([
    'supp001', 'Shree Textiles', '9812345670', 'info@shreetextiles.com',
    'Sector 12, Surat', 'Surat', '27AABCT1234A1Z0', 'ACC123456789', new Date().toISOString()
  ]);

  SpreadsheetApp.getUi().alert('✅ Setup complete! All sheets created with demo data.\n\nNow: Deploy > New Deployment > Web app\nCopy the URL to your frontend CONFIG.');
}

// ============================================================================
// HTTP HANDLERS
// ============================================================================
function doGet(e) {
  const action = e.parameter.action;
  try {
    switch (action) {
      case 'getAll': return jsonResponse(getAllData());
      case 'getLoginHistory': return jsonResponse(getLoginHistory());
      default: return jsonResponse({ error: 'Unknown action: ' + action });
    }
  } catch (err) {
    return jsonResponse({ error: err.message });
  }
}

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents);
    const { action, data } = body;
    let result;

    switch (action) {
      // AUTH
      case 'login': result = login(data); break;
      case 'verifyPin': result = verifyPin(data); break;
      case 'unlockUser': result = unlockUser(data); break;

      // PRODUCTS
      case 'addProduct': result = addProduct(data); break;
      case 'updateProduct': result = updateProduct(data); break;
      case 'deleteProduct': result = deleteProduct(data); break;
      case 'getProductByUID': result = getProductByUID(data.uid); break;

      // VARIANTS & STOCK
      case 'addVariant': result = addVariant(data); break;
      case 'updateStock': result = updateStock(data); break;
      case 'updateLocation': result = updateLocation(data); break;

      // CUSTOMERS
      case 'addCustomer': result = addCustomer(data); break;
      case 'updateCustomer': result = updateCustomer(data); break;

      // BILLING
      case 'addBill': result = addBill(data); break;
      case 'returnBill': result = returnBill(data); break;

      // SUPPLIERS & PURCHASES
      case 'addSupplier': result = addSupplier(data); break;
      case 'addPurchase': result = addPurchase(data); break;

      // EXPENSES
      case 'addExpense': result = addExpense(data); break;

      // LOGGING
      case 'logActivity': result = logActivity(data); break;

      default:
        result = { error: 'Unknown action: ' + action };
    }

    return jsonResponse({ success: true, data: result });
  } catch (err) {
    return jsonResponse({ success: false, error: err.toString() });
  }
}

function jsonResponse(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

// ============================================================================
// UTILITIES
// ============================================================================
function simpleHash(str) {
  // Simple hash - for production use bcrypt via a library or service
  return Utilities.computeDigest(
    Utilities.DigestAlgorithm.SHA_256,
    str,
    Utilities.Charset.UTF_8
  ).map(b => ('0' + (b & 0xFF).toString(16)).slice(-2)).join('');
}

function getSheet(name) {
  return SpreadsheetApp.getActiveSpreadsheet().getSheetByName(name);
}

function sheetToObjects(sheetName) {
  const sheet = getSheet(sheetName);
  const values = sheet.getDataRange().getValues();
  const headers = values[0];
  return values.slice(1)
    .filter(row => row.join('').trim())
    .map(row => {
      const obj = {};
      headers.forEach((h, i) => obj[h] = row[i]);
      return obj;
    });
}

function generateID(prefix) {
  return prefix + '_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

function generateUID() {
  const count = sheetToObjects(SHEET_TABS.PRODUCTS).length;
  return 'AKFH' + String(count + 1).padStart(6, '0');
}

function generateBarcode(uid) {
  return uid;
}

function generateQRCode(uid) {
  // QR code is generated client-side; this is just the data
  return 'https://fashionhub.example.com/product/' + uid;
}

// ============================================================================
// DATA RETRIEVAL
// ============================================================================
function getAllData() {
  const products = sheetToObjects(SHEET_TABS.PRODUCTS);
  const variants = sheetToObjects(SHEET_TABS.VARIANTS);
  
  // Nest variants under products
  const productMap = {};
  products.forEach(p => {
    productMap[p.ProductID] = { ...p, variants: [] };
  });
  variants.forEach(v => {
    if (productMap[v.ProductID]) {
      productMap[v.ProductID].variants.push(v);
    }
  });

  return {
    products: Object.values(productMap),
    customers: sheetToObjects(SHEET_TABS.CUSTOMERS),
    bills: sheetToObjects(SHEET_TABS.BILLS),
    billItems: sheetToObjects(SHEET_TABS.BILL_ITEMS),
    suppliers: sheetToObjects(SHEET_TABS.SUPPLIERS),
    purchases: sheetToObjects(SHEET_TABS.PURCHASES),
    staff: sheetToObjects(SHEET_TABS.STAFF),
    expenses: sheetToObjects(SHEET_TABS.EXPENSES),
  };
}

function getLoginHistory() {
  return sheetToObjects(SHEET_TABS.LOGIN_HISTORY);
}

// ============================================================================
// AUTHENTICATION
// ============================================================================
const MAX_FAILED_ATTEMPTS = 5;
const LOCK_MINUTES = 15;

function login(data) {
  const { mobile, password } = data;
  const staff = sheetToObjects(SHEET_TABS.STAFF);
  const user = staff.find(s => String(s.Mobile) === String(mobile));

  if (!user) {
    logLoginAttempt(mobile, '', '', 'Failed', 'No account found');
    return { success: false, error: 'No account with this mobile number' };
  }

  // Check if locked
  if (user.LockedUntil) {
    const lockedTime = new Date(user.LockedUntil).getTime();
    if (lockedTime > Date.now()) {
      logLoginAttempt(mobile, user.Name, user.Role, 'Blocked', 'Account locked');
      return { success: false, error: 'Account locked. Try again after ' + user.LockedUntil };
    }
  }

  // Verify password
  const passHash = simpleHash(password);
  if (user.PasswordHash !== passHash) {
    // Increment failed attempts
    const sheet = getSheet(SHEET_TABS.STAFF);
    const values = sheet.getDataRange().getValues();
    for (let i = 1; i < values.length; i++) {
      if (String(values[i][2]) === String(mobile)) {
        const attempts = (Number(values[i][9]) || 0) + 1;
        sheet.getRange(i + 1, 10).setValue(attempts);

        if (attempts >= MAX_FAILED_ATTEMPTS) {
          const lockUntil = new Date(Date.now() + LOCK_MINUTES * 60000).toISOString();
          sheet.getRange(i + 1, 11).setValue(lockUntil);
          logLoginAttempt(mobile, user.Name, user.Role, 'Locked', 'Too many failed attempts');
          return { success: false, error: 'Account locked for ' + LOCK_MINUTES + ' minutes' };
        }

        logLoginAttempt(mobile, user.Name, user.Role, 'Failed', 'Wrong password (' + attempts + '/' + MAX_FAILED_ATTEMPTS + ')');
        return { success: false, error: 'Wrong password (' + attempts + '/' + MAX_FAILED_ATTEMPTS + ')' };
      }
    }
  }

  // Successful login - reset attempts
  const sheet = getSheet(SHEET_TABS.STAFF);
  const values = sheet.getDataRange().getValues();
  for (let i = 1; i < values.length; i++) {
    if (String(values[i][2]) === String(mobile)) {
      sheet.getRange(i + 1, 10).setValue(0);
      sheet.getRange(i + 1, 11).setValue('');
      sheet.getRange(i + 1, 12).setValue(new Date().toISOString());
      break;
    }
  }

  logLoginAttempt(mobile, user.Name, user.Role, 'Success', '');

  return {
    success: true,
    user: {
      staffID: user.StaffID,
      name: user.Name,
      mobile: user.Mobile,
      role: user.Role,
      permissions: typeof user.Permissions === 'string' ? JSON.parse(user.Permissions) : user.Permissions,
      pinHash: user.PINHash
    }
  };
}

function verifyPin(data) {
  const { staffID, pin } = data;
  const staff = sheetToObjects(SHEET_TABS.STAFF);
  const user = staff.find(s => s.StaffID === staffID);

  if (!user) {
    return { success: false, error: 'User not found' };
  }

  const pinHash = simpleHash(pin);
  const isValid = user.PINHash === pinHash;

  if (!isValid) {
    logActivity({ staffID, action: 'FAILED_PIN_ATTEMPT', details: 'Invalid PIN entered' });
  }

  return { success: isValid };
}

function unlockUser(data) {
  const { mobile } = data;
  const sheet = getSheet(SHEET_TABS.STAFF);
  const values = sheet.getDataRange().getValues();

  for (let i = 1; i < values.length; i++) {
    if (String(values[i][2]) === String(mobile)) {
      sheet.getRange(i + 1, 10).setValue(0);
      sheet.getRange(i + 1, 11).setValue('');
      logActivity({ staffID: values[i][0], action: 'USER_UNLOCKED', details: 'Mobile: ' + mobile });
      return { success: true };
    }
  }

  return { success: false, error: 'User not found' };
}

function logLoginAttempt(mobile, name, role, status, reason) {
  const sheet = getSheet(SHEET_TABS.LOGIN_HISTORY);
  const logID = generateID('LOG');
  sheet.appendRow([
    logID, new Date().toISOString(), mobile, name, role, status, reason
  ]);
}

// ============================================================================
// PRODUCT OPERATIONS
// ============================================================================
function addProduct(data) {
  const {
    name, gender, description, brand, fabricType, costPrice, salePrice, mrp,
    batchNumber, tags, seasonTags, imageURL, sizeChartURL, supplierID
  } = data;

  const productSheet = getSheet(SHEET_TABS.PRODUCTS);
  const productID = generateID('PROD');
  const uid = generateUID();
  const barcode = generateBarcode(uid);
  const qrCode = generateQRCode(uid);

  productSheet.appendRow([
    productID, uid, barcode, qrCode, name, gender, description,
    brand, fabricType, 'Active', costPrice, salePrice, mrp,
    batchNumber, (tags || []).join('|'), (seasonTags || []).join('|'),
    imageURL, sizeChartURL, supplierID, 0, new Date().toISOString(), new Date().toISOString()
  ]);

  logActivity({ staffID: data.staffID, action: 'PRODUCT_CREATED', details: 'UID: ' + uid + ', Name: ' + name });

  return { productID, uid, barcode, qrCode };
}

function updateProduct(data) {
  const { productID, ...updateData } = data;
  const sheet = getSheet(SHEET_TABS.PRODUCTS);
  const values = sheet.getDataRange().getValues();
  const headers = values[0];

  for (let i = 1; i < values.length; i++) {
    if (values[i][0] === productID) {
      Object.entries(updateData).forEach(([key, value]) => {
        const colIdx = headers.indexOf(key);
        if (colIdx !== -1) {
          sheet.getRange(i + 1, colIdx + 1).setValue(value);
        }
      });
      sheet.getRange(i + 1, headers.indexOf('UpdatedDate') + 1).setValue(new Date().toISOString());
      logActivity({ staffID: data.staffID, action: 'PRODUCT_UPDATED', details: 'ProductID: ' + productID });
      return { success: true };
    }
  }

  return { success: false, error: 'Product not found' };
}

function deleteProduct(data) {
  const { productID, staffID } = data;
  const sheet = getSheet(SHEET_TABS.PRODUCTS);
  const values = sheet.getDataRange().getValues();

  for (let i = values.length - 1; i >= 1; i--) {
    if (values[i][0] === productID) {
      sheet.deleteRow(i + 1);
      logActivity({ staffID, action: 'PRODUCT_DELETED', details: 'ProductID: ' + productID });
      return { success: true };
    }
  }

  return { success: false, error: 'Product not found' };
}

function getProductByUID(uid) {
  const products = sheetToObjects(SHEET_TABS.PRODUCTS);
  const product = products.find(p => p.UID === uid);
  if (!product) return { success: false, error: 'Product not found' };

  const variants = sheetToObjects(SHEET_TABS.VARIANTS);
  product.variants = variants.filter(v => v.ProductID === product.ProductID);

  return { success: true, product };
}

// ============================================================================
// VARIANT & STOCK OPERATIONS
// ============================================================================
function addVariant(data) {
  const { productID, uid, color, size, stock, floor, rack, shelf, staffID } = data;
  const variantSheet = getSheet(SHEET_TABS.VARIANTS);
  const variantID = generateID('VAR');

  variantSheet.appendRow([
    variantID, productID, uid, color, size, stock, floor, rack, shelf, new Date().toISOString()
  ]);

  // Update product total stock
  updateProductTotalStock(productID);
  logActivity({ staffID, action: 'VARIANT_ADDED', details: 'VariantID: ' + variantID + ', Color: ' + color + ', Size: ' + size });

  return { success: true, variantID };
}

function updateStock(data) {
  const { variantID, qtyChange, staffID } = data;
  const sheet = getSheet(SHEET_TABS.VARIANTS);
  const values = sheet.getDataRange().getValues();

  for (let i = 1; i < values.length; i++) {
    if (values[i][0] === variantID) {
      const currentStock = Number(values[i][5]) || 0;
      const newStock = Math.max(0, currentStock + qtyChange);
      sheet.getRange(i + 1, 6).setValue(newStock);

      // Update product total
      updateProductTotalStock(values[i][1]);
      logActivity({ staffID, action: 'STOCK_UPDATED', details: 'VariantID: ' + variantID + ', Change: ' + qtyChange });

      return { success: true, newStock };
    }
  }

  return { success: false, error: 'Variant not found' };
}

function updateLocation(data) {
  const { variantID, floor, rack, shelf, staffID } = data;
  const sheet = getSheet(SHEET_TABS.VARIANTS);
  const values = sheet.getDataRange().getValues();

  for (let i = 1; i < values.length; i++) {
    if (values[i][0] === variantID) {
      sheet.getRange(i + 1, 7).setValue(floor);
      sheet.getRange(i + 1, 8).setValue(rack);
      sheet.getRange(i + 1, 9).setValue(shelf);
      logActivity({ staffID, action: 'LOCATION_UPDATED', details: 'VariantID: ' + variantID });
      return { success: true };
    }
  }

  return { success: false, error: 'Variant not found' };
}

function updateProductTotalStock(productID) {
  const variants = sheetToObjects(SHEET_TABS.VARIANTS);
  const totalStock = variants
    .filter(v => v.ProductID === productID)
    .reduce((sum, v) => sum + (Number(v.Stock) || 0), 0);

  const sheet = getSheet(SHEET_TABS.PRODUCTS);
  const values = sheet.getDataRange().getValues();

  for (let i = 1; i < values.length; i++) {
    if (values[i][0] === productID) {
      sheet.getRange(i + 1, 19).setValue(totalStock);
      break;
    }
  }
}

// ============================================================================
// CUSTOMER OPERATIONS
// ============================================================================
function addCustomer(data) {
  const { name, mobile, email, birthday, address, staffID } = data;
  const sheet = getSheet(SHEET_TABS.CUSTOMERS);
  const customerID = generateID('CUST');

  sheet.appendRow([
    customerID, name, mobile, email, birthday, address, 0, 0, 0, new Date().toISOString()
  ]);

  logActivity({ staffID, action: 'CUSTOMER_ADDED', details: 'Mobile: ' + mobile + ', Name: ' + name });
  return { success: true, customerID };
}

function updateCustomer(data) {
  const { customerID, ...updateData } = data;
  const sheet = getSheet(SHEET_TABS.CUSTOMERS);
  const values = sheet.getDataRange().getValues();
  const headers = values[0];

  for (let i = 1; i < values.length; i++) {
    if (values[i][0] === customerID) {
      Object.entries(updateData).forEach(([key, value]) => {
        const colIdx = headers.indexOf(key);
        if (colIdx !== -1) {
          sheet.getRange(i + 1, colIdx + 1).setValue(value);
        }
      });
      logActivity({ staffID: updateData.staffID, action: 'CUSTOMER_UPDATED', details: 'CustomerID: ' + customerID });
      return { success: true };
    }
  }

  return { success: false, error: 'Customer not found' };
}

// ============================================================================
// BILLING OPERATIONS
// ============================================================================
function addBill(data) {
  const {
    customerID, customerName, customerMobile, staffID, staffName, items,
    subtotal, discountPercent, discountAmount, taxAmount, totalAmount, paymentMode
  } = data;

  const billSheet = getSheet(SHEET_TABS.BILLS);
  const billID = generateID('BILL');
  const billNumber = 'BILL-' + Date.now();

  billSheet.appendRow([
    billID, billNumber, customerID, customerName, customerMobile,
    staffID, staffName, subtotal, discountPercent, discountAmount,
    taxAmount, totalAmount, paymentMode, 'Completed', new Date().toISOString()
  ]);

  // Add bill items and update stock
  const itemSheet = getSheet(SHEET_TABS.BILL_ITEMS);
  items.forEach(item => {
    itemSheet.appendRow([
      billID, item.variantID, item.productID, item.uid, item.color, item.size,
      item.quantity, item.salePrice, item.quantity * item.salePrice
    ]);

    // Reduce stock
    updateStock({ variantID: item.variantID, qtyChange: -item.quantity, staffID });
  });

  // Update customer spend and loyalty
  if (customerID && customerID !== 'walk-in') {
    const custSheet = getSheet(SHEET_TABS.CUSTOMERS);
    const custValues = custSheet.getDataRange().getValues();
    for (let i = 1; i < custValues.length; i++) {
      if (custValues[i][0] === customerID) {
        const newSpend = (Number(custValues[i][6]) || 0) + totalAmount;
        const newLoyalty = (Number(custValues[i][7]) || 0) + Math.floor(totalAmount / 100);
        custSheet.getRange(i + 1, 7).setValue(newSpend);
        custSheet.getRange(i + 1, 8).setValue(newLoyalty);
        break;
      }
    }
  }

  logActivity({ staffID, action: 'BILL_CREATED', details: 'BillNumber: ' + billNumber + ', Amount: ' + totalAmount });

  return { success: true, billID, billNumber };
}

function returnBill(data) {
  const { billID, variantID, quantity, staffID } = data;
  updateStock({ variantID, qtyChange: quantity, staffID });
  logActivity({ staffID, action: 'BILL_RETURNED', details: 'BillID: ' + billID + ', Quantity: ' + quantity });
  return { success: true };
}

// ============================================================================
// SUPPLIER & PURCHASE OPERATIONS
// ============================================================================
function addSupplier(data) {
  const { name, mobile, email, address, city, gstin, bankAccount, staffID } = data;
  const sheet = getSheet(SHEET_TABS.SUPPLIERS);
  const supplierID = generateID('SUPP');

  sheet.appendRow([
    supplierID, name, mobile, email, address, city, gstin, bankAccount, new Date().toISOString()
  ]);

  logActivity({ staffID, action: 'SUPPLIER_ADDED', details: 'Name: ' + name });
  return { success: true, supplierID };
}

function addPurchase(data) {
  const { supplierID, supplierName, variantID, productID, uid, color, size, quantity, costPrice, staffID } = data;
  const sheet = getSheet(SHEET_TABS.PURCHASES);
  const purchaseID = generateID('PUR');
  const totalAmount = quantity * costPrice;

  sheet.appendRow([
    purchaseID, supplierID, supplierName, variantID, productID, uid, color, size,
    quantity, costPrice, totalAmount, '', new Date().toISOString()
  ]);

  // Increase stock
  updateStock({ variantID, qtyChange: quantity, staffID });
  logActivity({ staffID, action: 'PURCHASE_CREATED', details: 'SupplierID: ' + supplierID + ', Quantity: ' + quantity });

  return { success: true, purchaseID };
}

// ============================================================================
// EXPENSE OPERATIONS
// ============================================================================
function addExpense(data) {
  const { date, category, description, amount, staffName, notes, staffID } = data;
  const sheet = getSheet(SHEET_TABS.EXPENSES);
  const expenseID = generateID('EXP');

  sheet.appendRow([
    expenseID, date, category, description, amount, staffName, notes, new Date().toISOString()
  ]);

  logActivity({ staffID, action: 'EXPENSE_ADDED', details: 'Amount: ' + amount + ', Category: ' + category });
  return { success: true, expenseID };
}

// ============================================================================
// LOGGING
// ============================================================================
function logActivity(data) {
  const { staffID, action, details } = data;
  const sheet = getSheet(SHEET_TABS.ACTIVITY_LOG);
  const logID = generateID('ACT');

  const staff = sheetToObjects(SHEET_TABS.STAFF).find(s => s.StaffID === staffID);
  const staffName = staff ? staff.Name : 'Unknown';

  sheet.appendRow([
    logID, new Date().toISOString(), staffID, staffName, action, details
  ]);
}
